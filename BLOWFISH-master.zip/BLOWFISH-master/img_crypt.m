clc
clear all
%img = uigetfile('*.jpeg','select image');
%img = imread('1.jpg');
%gimg=img;
I_temp=imread(uigetfile('*.jpeg','select image'));
if size(I_temp,3)==3
   I_temp=rgb2gray(I_temp);
end
gimg = I_temp;
%gimg(1,1:16)
gimg = gimg(:,1:end-1);
dim = size(gimg);
ct = img_encrypt(gimg);
cti = reshape(ct,dim);
figure,imshow(mat2gray(cti));
ot = img_decrypt(ct);
oti = reshape(ot,dim);
figure,
%imshow(oti);
imshow(mat2gray(oti));
%ct = img_encrypt(gimg(1,9:16))
%ot = img_decrypt(ct)