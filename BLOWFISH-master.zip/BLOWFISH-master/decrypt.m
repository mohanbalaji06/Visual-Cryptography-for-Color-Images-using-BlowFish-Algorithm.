rgbImage = imread('share1.jpg');
im = imread('sm.jpg');
% Extract color channels.
%{
rr = rgbImage(:,:,1);
gg = rgbImage(:,:,2); 
bb = rgbImage(:,:,3);
%}
%{
share11 = uigetfile('*.jpg','select image');
rr = share11( :, :, 1);
gg = share11( :, :, 2); 
bb = share11( :, :, 3);
%}

rgbImage1 = imread('share2.jpg');

% Extract color channels.
%{
rr1 = rgbImage1(:,:,1);
gg1 = rgbImage1(:,:,2); 
bb1 = rgbImage1(:,:,3);
%}

%{
share22 = uigetfile('*.jpeg','select image');
rr1 = share22(:,:,1);
gg1 = share22(:,:,2); 
bb1 = share22(:,:,3);
%}
B = randi([1 255],225,225,'uint8');

rss1=bitxor(rgbImage,B);
rss2=bitxor(rgbImage1,B);
gss1=bitxor(rgbImage,B);
gss2=bitxor(rgbImage1,B);
bss1=bitxor(rgbImage,B);
bss2=bitxor(rgbImage1,B);

rrr=rss1(:,:,1);
rrr1=rss2(:,:,1);
ggg=gss1(:,:,2);
ggg1=gss1(:,:,2);
bbb=bss1(:,:,3);
bbb1=bss2(:,:,3);

red=rrr+rrr1;
green=ggg+ggg1;
blue=bbb+bbb1;

trueImage=cat(3,red,green,blue);
figure;
imshow(trueImage);
