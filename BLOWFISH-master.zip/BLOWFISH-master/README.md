# BLOWFISH
Implementation of BLOWFISH algorithm on image.

img_crypt.m file is the main file 

this code runs on gray image and can be further 
extened to run on the RGB images. 

For any difficulty or error you may 
contact me via email

singhdeepak.15@gmail.com
