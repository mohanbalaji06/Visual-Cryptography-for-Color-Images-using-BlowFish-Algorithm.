rgbImage = imread('sm.jpg');
im = imread('sm.jpg');
% Extract color channels.
redChannel = rgbImage(:,:,1);
greenChannel = rgbImage(:,:,2); 
blueChannel = rgbImage(:,:,3);
%Create an all black channel.

allBlack = zeros(size(rgbImage, 1), size(rgbImage, 2), 'uint8');

% Create color versions of the individual color channels.
just_red = cat(3, redChannel, allBlack, allBlack);
just_green = cat(3, allBlack, greenChannel, allBlack);
just_blue = cat(3, allBlack, allBlack, blueChannel);
recombinedRGBImage = cat(3, redChannel, greenChannel, blueChannel);

k=recombinedRGBImage/2;
% Display them all.
figure;
imshow(rgbImage);


fontSize = 20;
title('Original RGB Image', 'FontSize', fontSize)
figure;
subplot(1, 3, 1);
imshow(just_red);
title('Red Channel', 'FontSize', fontSize)
subplot(1, 3, 2);
imshow(just_green)
title('Green Channel', 'FontSize', fontSize)
subplot(1, 3, 3);
imshow(just_blue);
title('Blue Channel', 'FontSize', fontSize)

r1= floor(just_red / 2);
r2= ceil(just_red / 2);
g1=floor(just_green / 2);
g2 = ceil(just_green / 2);
b1=floor(just_blue / 2);
b2 = ceil(just_blue / 2);

%r222 = randi(255,255,1);
[row ,col] = size(just_red);
 B = randi([1 255],225,225,'uint8');
 disp(B);
%{
figure;
subplot(2,3,1);
imshow(r1);

subplot(2,3,2);
imshow(r2);

subplot(2,3,3);
imshow(g1);

subplot(2,3,4);
imshow(g2);

subplot(2,3,5);
imshow(b1);

subplot(2,3,6);
imshow(b2);

%}
  
rs1=bitxor(r1,B);
rs2=bitxor(r2,B);
gs1=bitxor(g1,B);
gs2=bitxor(g2,B);
bs1=bitxor(b1,B);
bs2=bitxor(b2,B);
%{
figure;
imshow(rs1);
figure;
imshow(rs2);
figure;
imshow(gs1);
figure;
imshow(gs2);
figure;
imshow(bs1);
figure;
imshow(bs2);
%}
sample=rs1(:,:,1);

rr = rs1(:,:,1);
gg = gs1(:,:,2); 
bb = bs1(:,:,3);

disp(class(just_red));
%disp(class(share1));
share1 = cat(3, rr, gg, bb);
disp(class(share1));

rr1 = rs2(:,:,1);
gg1 = gs2(:,:,2); 
bb1 = bs2(:,:,3);

share2 = cat(3, rr1, gg1, bb1);

figure;

imshow(share1);
title('share1', 'FontSize', fontSize)

figure;
imshow(share2);
title('share2', 'FontSize', fontSize)
imwrite(share1,'share1.jpg');
imwrite(share2,'share2.jpg');

o=BlowFish;
javaMethod('main',o,'');

m=Encrypt;
javaMethod('main',m,'');

dshare1=imread('decrypt.jpg');
dshare2=imread('decrypt1.jpg');

drs1=dshare1(:,:,1);
dgs1=dshare1(:,:,2);
dbs1=dshare1(:,:,3);

drs2=dshare2(:,:,1);
dgs2=dshare2(:,:,2);
dbs2=dshare2(:,:,3);

ors1=bitxor(drs1,B);
ors2=bitxor(drs2,B);
ogs1=bitxor(dgs1,B);
ogs2=bitxor(dgs2,B);
obs1=bitxor(dbs1,B);
obs2=bitxor(dbs2,B);

red1=ors1+ors2;
red=red1(:,:,1);
green1=ogs1+ogs2;
green=green1(:,:,2);
blue1=obs1+obs2;
blue=blue1(:,:,3);

superimpose_img=cat(3,red,blue,green);
%superimpose_img=cat(3,superimpose_img,superimpose_img,superimpose_img);
%rgbVivid = hsv2rgb(rgb2hsv(superimpose_img) .* cat(3, 1, 2, 1));
%superimpose_img1=medfilt(superimpose_img,[3 3]);
figure;
imshow(superimpose_img);


